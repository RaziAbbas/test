./stop.sh
./init.sh
rm -r qdata/
rm -r deployed/
rm -rf /vagrant/examples
cp -r /home/ubuntu/quorum-examples /vagrant/examples
