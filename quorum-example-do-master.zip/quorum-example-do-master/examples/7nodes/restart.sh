./stop.sh
./init.sh
./start.sh
