#!/bin/bash
killall geth bootnode constellation-node
