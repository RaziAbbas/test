#!/bin/bash

killall geth bootnode

